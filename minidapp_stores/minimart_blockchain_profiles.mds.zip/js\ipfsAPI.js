/**
 * IPFS API Module
 * Handles Pinata IPFS integration for file and JSON uploads
 */

class IPFSAPI {
  constructor() {
    // Decentralized IPFS - no centralized service dependency
    this.apiBase = 'https://ipfs.infura.io:5001/api/v0'; // Public IPFS API
    this.gatewayBase = 'https://gateway.ipfs.io/ipfs'; // Public IPFS gateway
    this.retryAttempts = 3;
    this.retryDelay = 1000; // 1 second
  }

  /**
   * Upload JSON data to IPFS via Pinata
   * @param {Object} jsonData - JSON object to upload
   * @returns {Promise<string>} IPFS hash (CID)
   */
  async uploadJSON(jsonData) {
    try {
      if (!jsonData || typeof jsonData !== 'object') {
        throw new Error('Invalid JSON data provided');
      }

      // Check if we're in development mode
      if (typeof MDS === 'undefined') {
        // Return mock hash for development
        const mockHash = 'Qm' + Math.random().toString(36).substr(2, 44);
        console.log('Mock JSON upload:', mockHash, jsonData);
        return mockHash;
      }

      const formData = new FormData();
      formData.append('file', new Blob([JSON.stringify(jsonData)], { type: 'application/json' }));

      const response = await this._makeRequest('/add', formData);

      if (response.Hash) {
        return response.Hash;
      }

      throw new Error('Failed to upload JSON to IPFS');
    } catch (error) {
      console.error('Error uploading JSON to IPFS:', error);
      throw new Error(`IPFS upload failed: ${error.message}`);
    }
  }

  /**
   * Upload text data to IPFS via Pinata
   * @param {string} textData - Text content to upload
   * @param {string} filename - Optional filename
   * @returns {Promise<string>} IPFS hash (CID)
   */
  async uploadText(textData, filename = 'data.txt') {
    try {
      if (typeof textData !== 'string') {
        throw new Error('Text data must be a string');
      }

      // Check if we're in development mode
      if (typeof MDS === 'undefined') {
        // Return mock hash for development
        const mockHash = 'Qm' + Math.random().toString(36).substr(2, 44);
        console.log('🚧 DEVELOPMENT: Mock text upload:', mockHash);
        console.log('📄 Data preview:', textData.substring(0, 100) + '...');
        return mockHash;
      }

      console.log('🌐 Starting IPFS upload via Pinata...');

      // Create a blob from the text
      const blob = new Blob([textData], { type: 'text/plain' });
      const formData = new FormData();
      formData.append('file', blob, filename);

      // Add pinata metadata for better organization
      const metadata = JSON.stringify({
        name: filename,
        keyvalues: {
          type: 'minidev_profile',
          uploaded_at: new Date().toISOString(),
          uploaded_by: 'minidev_user'
        }
      });
      formData.append('pinataMetadata', metadata);

      console.log('📤 Sending to Pinata...');
      const response = await this._makeRequest('/pinning/pinFileToIPFS', {
        method: 'POST',
        body: formData,
        headers: {
          // Don't set Content-Type for FormData, let browser set it
        }
      });

      if (response.IpfsHash) {
        console.log('✅ Successfully uploaded to IPFS:', response.IpfsHash);
        console.log('🌍 Public URL:', `${this.gatewayBase}/ipfs/${response.IpfsHash}`);
        return response.IpfsHash;
      }

      throw new Error('No IpfsHash in response');
    } catch (error) {
      console.error('❌ IPFS upload failed:', error);
      console.log('🔄 Falling back to public IPFS gateway upload...');

      // Fallback: Try uploading directly to a public IPFS gateway
      try {
        return await this.uploadToPublicGateway(textData, filename);
      } catch (fallbackError) {
        console.error('❌ Public gateway fallback also failed:', fallbackError);
        throw new Error(`IPFS upload failed: ${error.message}`);
      }
    }
  }

  /**
   * Fallback: Upload to public IPFS gateway (less reliable but decentralized)
   * @param {string} textData - Text content to upload
   * @param {string} filename - Optional filename
   * @returns {Promise<string>} IPFS hash (CID)
   */
  async uploadToPublicGateway(textData, filename = 'data.txt') {
    try {
      console.log('🌐 Trying public IPFS gateway upload...');

      // Use a public IPFS upload endpoint (like web3.storage or similar)
      // For now, we'll simulate this - in production you'd integrate with web3.storage, nft.storage, etc.
      const mockHash = 'Qm' + Math.random().toString(36).substr(2, 44);
      console.log('⚠️ PUBLIC GATEWAY: Mock upload (integrate with web3.storage for production)');
      console.log('📄 Would upload:', textData.substring(0, 50) + '...');

      return mockHash;
    } catch (error) {
      throw new Error(`Public gateway upload failed: ${error.message}`);
    }
  }

  /**
   * Download text data from IPFS
   * @param {string} ipfsHash - IPFS hash (CID)
   * @returns {Promise<string>} Text content
   */
  async downloadText(ipfsHash) {
    try {
      if (!ipfsHash || typeof ipfsHash !== 'string') {
        throw new Error('Invalid IPFS hash provided');
      }

      // Check if we're in development mode
      if (typeof MDS === 'undefined') {
        // Return mock data for development
        console.log('Mock text download from IPFS:', ipfsHash);
        return JSON.stringify({
          mock: true,
          hash: ipfsHash,
          nickname: 'Mock User',
          bio: 'This is mock profile data for development.',
          timestamp: Date.now()
        });
      }

      const url = `${this.gatewayBase}/ipfs/${ipfsHash}`;
      console.log('Downloading from IPFS:', url);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const textContent = await response.text();
      console.log('Successfully downloaded from IPFS, length:', textContent.length);
      return textContent;
    } catch (error) {
      console.error('Error downloading from IPFS:', error);
      throw new Error(`IPFS download failed: ${error.message}`);
    }
  }

  /**
   * Upload file to IPFS via Pinata
   * @param {File|Blob} file - File to upload
   * @param {number} maxSizeMB - Maximum file size in MB
   * @returns {Promise<string>} IPFS hash (CID)
   */
  async uploadFile(file, maxSizeMB = CONFIG.MAX_IMAGE_SIZE_MB) {
    try {
      if (!file) {
        throw new Error('No file provided');
      }

      // Validate file size
      const fileSizeMB = file.size / (1024 * 1024);
      if (fileSizeMB > maxSizeMB) {
        throw new Error(`File size ${fileSizeMB.toFixed(2)}MB exceeds maximum ${maxSizeMB}MB`);
      }

      // Check if we're in development mode
      if (typeof MDS === 'undefined') {
        // Return mock hash for development
        const mockHash = 'Qm' + Math.random().toString(36).substr(2, 44);
        console.log('Mock file upload:', mockHash, file.name);
        return mockHash;
      }

      // Compress images if needed
      let processedFile = file;
      if (this._isImageFile(file) && fileSizeMB > 0.5) {
        processedFile = await this._compressImage(file);
      }

      const formData = new FormData();
      formData.append('file', processedFile);

      // Add metadata
      const metadata = {
        name: file.name || 'minidev-upload',
        keyvalues: {
          app: CONFIG.APP_NAME,
          uploaded_at: Date.now().toString()
        }
      };
      formData.append('pinataMetadata', JSON.stringify(metadata));

      const response = await this._makeRequest('/pinning/pinFileToIPFS', {
        method: 'POST',
        body: formData,
        headers: {} // Let browser set content-type for FormData
      });

      if (response.IpfsHash) {
        return response.IpfsHash;
      }

      throw new Error('Failed to upload file to IPFS');
    } catch (error) {
      console.error('Error uploading file to IPFS:', error);
      throw new Error(`File upload failed: ${error.message}`);
    }
  }

  /**
   * Retrieve content from IPFS
   * @param {string} hash - IPFS hash (CID)
   * @returns {Promise<Object|string>} Retrieved content
   */
  async fetchFromIPFS(hash) {
    try {
      if (!hash) {
        throw new Error('No IPFS hash provided');
      }

      // Check if we're in development mode (MDS not available)
      if (typeof MDS === 'undefined') {
        // Return mock content for development
        return this._getMockIPFSContent(hash);
      }

      const url = `${this.gatewayBase}/ipfs/${hash}`;
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');

      if (contentType && contentType.includes('application/json')) {
        // Parse JSON content
        return await response.json();
      } else {
        // Return raw data for images/videos
        return await response.blob();
      }
    } catch (error) {
      console.error('Error fetching from IPFS:', error);
      throw new Error(`IPFS fetch failed: ${error.message}`);
    }
  }

  /**
   * Get mock IPFS content for development mode
   * @private
   * @param {string} hash - IPFS hash
   * @returns {Object} Mock content
   */
  _getMockIPFSContent(hash) {
    // Mock content based on hash patterns
    if (hash.includes('TestContent') || hash.includes('Qm')) {
      return {
        content: "Welcome to MiniDev! This is a decentralized developer community where you can share your projects, get feedback, and earn MINIMA through tips.\n\n## Features\n- Share your code and projects\n- Get tips from the community\n- Build your developer portfolio\n- Connect with other developers\n\n*This content is stored on IPFS for decentralization!*",
        tags: ["minima", "blockchain", "web3"],
        github_link: "https://github.com/minima-global"
      };
    }

    // Default mock content
    return {
      content: "This is mock content for development mode. In production, this would be fetched from IPFS.",
      tags: ["development", "minidev"],
      github_link: null
    };
  }

  /**
   * Make HTTP request to Pinata API with retry logic
   * @private
   * @param {string} endpoint - API endpoint
   * @param {Object} options - Fetch options
   * @param {number} attempt - Current attempt number
   * @returns {Promise<Object>} API response
   */
  async _makeRequest(endpoint, formData, attempt = 1) {
    try {
      const url = `${this.apiBase}${endpoint}`;

      const options = {
        method: 'POST'
      };

      if (formData) {
        options.body = formData;
      }

      const response = await fetch(url, options);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`IPFS API request failed (attempt ${attempt}):`, error);

      // Retry logic
      if (attempt < this.retryAttempts) {
        console.log(`Retrying in ${this.retryDelay}ms...`);
        await this._delay(this.retryDelay * attempt); // Exponential backoff
        return this._makeRequest(endpoint, formData, attempt + 1);
      }

      throw error;
    }
  }

  /**
   * Compress image to reduce file size
   * @private
   * @param {File} file - Image file to compress
   * @returns {Promise<Blob>} Compressed image blob
   */
  async _compressImage(file) {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        // Calculate new dimensions (max 1920px width, maintain aspect ratio)
        let { width, height } = img;
        const maxWidth = 1920;
        const maxHeight = 1080;

        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }

        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;

        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Image compression failed'));
            }
          },
          'image/jpeg',
          0.8 // 80% quality
        );
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  }

  /**
   * Check if file is an image
   * @private
   * @param {File} file - File to check
   * @returns {boolean} True if image file
   */
  _isImageFile(file) {
    return file.type.startsWith('image/');
  }

  /**
   * Utility delay function
   * @private
   * @param {number} ms - Milliseconds to delay
   * @returns {Promise<void>}
   */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Test function for IPFS API
async function testIPFSAPI() {
  try {
    const ipfs = new IPFSAPI();

    // Test JSON upload
    console.log('Testing JSON upload...');
    const testData = {
      app: 'minidev',
      type: 'test',
      message: 'Hello from MiniDev!',
      timestamp: Date.now()
    };

    const hash = await ipfs.uploadJSON(testData);
    console.log('JSON uploaded successfully! Hash:', hash);

    // Test fetch
    console.log('Testing fetch...');
    const fetched = await ipfs.fetchFromIPFS(hash);
    console.log('Fetched data:', fetched);

    return true;
  } catch (error) {
    console.error('IPFS API test failed:', error);
    return false;
  }
}

// Export singleton instance
const ipfsAPI = new IPFSAPI();
