/**
 * Blockchain API - Permanent Layer for MiniDev
 *
 * Handles permanent on-chain records:
 * - Dapp registration (IPFS hash, name, developer address)
 * - Developer identity verification (optional)
 *
 * Cost: 0.01 Minima per dapp registration (~$0.0001)
 * Purpose: Permanent catalog that survives if Maxima network issues occur
 */

class BlockchainAPI {
    constructor() {
        this.isReady = false;
        this.minimaAPI = null;
    }

    async init(minimaAPI) {
        try {
            console.log('🔄 Initializing Blockchain API...');
            this.minimaAPI = minimaAPI;

            // Wait for Minima to be ready
            if (!minimaAPI || !minimaAPI.isReady) {
                console.log('Waiting for Minima API...');
                for (let i = 0; i < 50; i++) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                    if (minimaAPI && minimaAPI.isReady) break;
                }
            }

            this.isReady = true;
            console.log('🎉 Blockchain API initialized');

            return true;
        } catch (error) {
            console.error('❌ Blockchain API init failed:', error);
            return false;
        }
    }

    /**
     * Register a dapp permanently on the blockchain
     * @param {Object} dapp - Dapp metadata
     * @param {string} developerAddress - Developer address
     * @returns {Promise<string>} Transaction ID
     */
    async registerDapp(dapp, developerAddress) {
        try {
            if (!this.isReady) {
                throw new Error('Blockchain API not ready');
            }

            console.log('📝 Registering dapp on blockchain:', dapp.name);

            // Create transaction with dapp data in state
            const transactionData = {
                amount: '0.01', // Small registration fee
                address: 'MxG086AUGQMWM6S47P6GWR2U1AV3391EPR5Q53N7DN9MGNMMN6BMH270SV8QRSC', // MiniMart Treasury (your address)
                state: {
                    type: 'minidev_dapp_registration',
                    dapp_uid: dapp.uid,
                    name: dapp.name,
                    version: dapp.version,
                    description: dapp.description,
                    category: dapp.category,
                    ipfs_hash: dapp.ipfs_hash,
                    developer_address: developerAddress,
                    timestamp: Date.now(),
                    registration_fee: '0.01'
                }
            };

            console.log('🔐 Sending dapp registration transaction...');
            const txId = await this.minimaAPI.sendCustomTransaction(transactionData);

            console.log('✅ Dapp registered on blockchain with TX:', txId);
            return txId;

        } catch (error) {
            console.error('❌ Dapp registration failed:', error);
            throw error;
        }
    }

    /**
     * Query blockchain for registered dapps
     * @param {number} limit - Max results to return
     * @returns {Promise<Array>} Array of registered dapps
     */
    async queryRegisteredDapps(limit = 100) {
        try {
            if (!this.isReady) {
                throw new Error('Blockchain API not ready');
            }

            console.log('🔍 Querying blockchain for registered dapps...');

            // This is a simplified version - in practice you'd need to
            // scan blockchain transactions with minidev_dapp_registration type
            // For now, return empty array (would be populated by real blockchain scanning)

            console.log('ℹ️ Blockchain query not yet implemented - returning empty results');
            return [];

        } catch (error) {
            console.error('❌ Blockchain query failed:', error);
            return [];
        }
    }

    /**
     * Get dapp registration details by UID
     * @param {string} dappUid - Dapp unique identifier
     * @returns {Promise<Object|null>} Dapp registration data or null
     */
    async getDappRegistration(dappUid) {
        try {
            if (!this.isReady) {
                throw new Error('Blockchain API not ready');
            }

            console.log('🔍 Looking up dapp registration:', dappUid);

            // This would scan blockchain for transactions containing this dapp UID
            // For now, return null (would be populated by real blockchain scanning)

            console.log('ℹ️ Blockchain lookup not yet implemented');
            return null;

        } catch (error) {
            console.error('❌ Dapp registration lookup failed:', error);
            return null;
        }
    }

    /**
     * Verify dapp ownership on blockchain
     * @param {string} dappUid - Dapp unique identifier
     * @param {string} claimedOwner - Address claiming ownership
     * @returns {Promise<boolean>} True if ownership verified
     */
    async verifyDappOwnership(dappUid, claimedOwner) {
        try {
            const registration = await this.getDappRegistration(dappUid);

            if (!registration) {
                console.log('❌ Dapp not found on blockchain');
                return false;
            }

            const isOwner = registration.developer_address === claimedOwner;
            console.log('🔍 Dapp ownership verified:', isOwner);

            return isOwner;

        } catch (error) {
            console.error('❌ Ownership verification failed:', error);
            return false;
        }
    }

    /**
     * Optional: Register developer identity on blockchain
     * @param {string} developerAddress - Developer address
     * @param {string} identityHash - IPFS hash of identity verification
     * @returns {Promise<string>} Transaction ID
     */
    async registerDeveloperIdentity(developerAddress, identityHash) {
        try {
            if (!this.isReady) {
                throw new Error('Blockchain API not ready');
            }

            console.log('🆔 Registering developer identity on blockchain');

            const transactionData = {
                amount: '0.001', // Very small fee for identity
                address: 'MxG086AUGQMWM6S47P6GWR2U1AV3391EPR5Q53N7DN9MGNMMN6BMH270SV8QRSC', // MiniMart Treasury (your address)
                state: {
                    type: 'minidev_developer_identity',
                    developer_address: developerAddress,
                    identity_hash: identityHash,
                    timestamp: Date.now()
                }
            };

            const txId = await this.minimaAPI.sendCustomTransaction(transactionData);
            console.log('✅ Developer identity registered with TX:', txId);

            return txId;

        } catch (error) {
            console.error('❌ Developer identity registration failed:', error);
            throw error;
        }
    }
}

// Initialize global instance
window.blockchainAPI = new BlockchainAPI();
