/**
 * MiniMart - Simple Decentralized Marketplace
 * Clean, focused marketplace for MiniDapps
 */

console.log('MiniMart: Starting...');

class MiniMartApp {
    constructor() {
        this.currentView = 'marketplace';
        this.dapps = [];
        this.userProfile = null;
        this.isInitialized = false;
    }

    async init() {
        console.log('MiniMart: Initializing app...');

        try {
            // Initialize Minima API first
            await window.minimaAPI.init();
            console.log('MiniMart: Minima API ready');

            // Initialize Maxima for live updates
            await window.maximaAPI.init();
            console.log('MiniMart: Maxima API ready');

            // Initialize Blockchain API
            await window.blockchainAPI.init(window.minimaAPI);
            console.log('MiniMart: Blockchain API ready');

            // Setup event listeners
            this.setupEventListeners();
            this.setupTreasuryButton();

            // Load initial data
            await this.loadInitialData();
            await this.updateTreasuryAmount();

            // Setup Maxima message handling
            this.setupMaximaMessages();

            this.isInitialized = true;
            this.hideLoading();

            console.log('MiniMart: App initialized successfully!');

        } catch (error) {
            console.error('MiniMart: Initialization failed:', error);
            this.showError('Failed to initialize MiniMart. Please refresh and try again.');
        }
    }

    setupEventListeners() {
        // Bottom Navigation
        document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const view = e.currentTarget.dataset.view;
                this.switchView(view);
            });
        });
    }

    setupTreasuryButton() {
        const treasuryBtn = document.getElementById('treasury-btn');
        if (treasuryBtn) {
            treasuryBtn.addEventListener('click', () => {
                this.showTreasuryModal();
            });
        }
    }

    async updateTreasuryAmount() {
        try {
            // For now, estimate based on user activity
            // In production, this would query the treasury address balance
            const totalUsers = Math.max(this.dapps.length * 2, 1); // Rough estimate
            const estimatedTreasury = totalUsers * 0.01; // 0.01 MINIMA per user

            const amountElement = document.getElementById('treasury-amount');
            if (amountElement) {
                amountElement.textContent = estimatedTreasury.toFixed(2);
            }
        } catch (error) {
            console.error('MiniMart: Failed to update treasury amount:', error);
        }
    }

    setupMaximaMessages() {
        window.maximaAPI.listenForMessages((message) => {
            this.handleMaximaMessage(message);
        });
    }

    async handleMaximaMessage(message) {
        console.log('MiniMart: Received Maxima message:', message);

        switch (message.type) {
            case 'minidev_new_dapp':
                await this.handleNewDapp(message.dapp);
                break;
            case 'minidev_profile_update':
                await this.handleProfileUpdate(message.profile);
                break;
            default:
                console.log('MiniMart: Unknown message type:', message.type);
        }
    }

    async handleNewDapp(dapp) {
        console.log('MiniMart: New dapp received:', dapp);
        this.dapps.unshift(dapp); // Add to beginning
        this.refreshMarketplace();
    }

    async handleProfileUpdate(profile) {
        console.log('MiniMart: Profile update received:', profile);
        // Handle profile updates if needed
    }

    async loadInitialData() {
        console.log('MiniMart: Loading initial data...');

        try {
            // Load dapps from blockchain
            const blockchainDapps = await window.blockchainAPI.queryRegisteredDapps();
            this.dapps = blockchainDapps || [];

            console.log('MiniMart: Loaded', this.dapps.length, 'dapps from blockchain');

            // Refresh marketplace display
            this.refreshMarketplace();

        } catch (error) {
            console.error('MiniMart: Failed to load initial data:', error);
        }
    }

    switchView(viewName) {
        console.log('MiniMart: Switching to view:', viewName);

        // Update bottom navigation
        document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === viewName);
        });

        // Update views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.toggle('active', view.id === `${viewName}-view`);
            view.classList.toggle('hidden', view.id !== `${viewName}-view`);
        });

            this.currentView = viewName;

            // Load view-specific data
            switch (viewName) {
            case 'marketplace':
                this.refreshMarketplace();
                    break;
            case 'publish':
                this.showPublishForm();
                    break;
            case 'profile':
                this.showProfile();
                    break;
            case 'pending':
                this.showPending();
                    break;
        }
    }

    refreshMarketplace() {
        const grid = document.getElementById('marketplace-grid');
        if (!grid) return;

        if (this.dapps.length === 0) {
            grid.innerHTML = `
                <div class="empty-market">
                    <div class="empty-icon">📱</div>
                    <h3>No Apps Yet</h3>
                    <p>Be the first to upload!</p>
                    <button class="upload-btn" onclick="window.app.switchView('publish')">
                        <span>+</span>
                    </button>
                </div>
            `;
            return;
        }

        // Sort by downloads (most popular first)
        const sortedDapps = [...this.dapps].sort((a, b) => (b.downloads || 0) - (a.downloads || 0));

        grid.innerHTML = sortedDapps.map(dapp => this.renderAppIcon(dapp)).join('');
    }

    renderAppIcon(dapp) {
        return `
            <div class="app-icon" data-uid="${dapp.uid}" onclick="window.app.showAppDetails('${dapp.uid}')">
                <div class="app-icon-image">
                    ${dapp.icon ? `<img src="${dapp.icon}" alt="${dapp.name}" onerror="this.style.display='none'">` : ''}
                    ${!dapp.icon ? '📱' : ''}
            </div>
                <div class="app-icon-info">
                    <div class="app-name">${this.escapeHtml(dapp.name)}</div>
                    <div class="app-developer">${this.shortenAddress(dapp.developer_address)}</div>
                    <div class="app-downloads">${dapp.downloads || 0} downloads</div>
                    </div>
            </div>
        `;
    }

    async downloadDapp(dappUid) {
        try {
            console.log('MiniMart: Downloading dapp:', dappUid);

            // Broadcast download event via Maxima
            const dapp = this.dapps.find(d => d.uid === dappUid);
            if (dapp) {
                await window.maximaAPI.broadcastDownload(dappUid, window.minimaAPI.getCurrentAddress());
                // Update local download count
                dapp.downloads = (dapp.downloads || 0) + 1;
                this.refreshMarketplace();
            }

            this.showToast('Download started! Check your MiniDapp store.', 'success');

        } catch (error) {
            console.error('MiniMart: Download failed:', error);
            this.showToast('Download failed. Please try again.', 'error');
        }
    }

    showAppDetails(dappUid) {
        const dapp = this.dapps.find(d => d.uid === dappUid);
        if (!dapp) return;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal app-modal">
                <div class="modal-header">
                    <div class="app-detail-header">
                        <div class="app-detail-icon">
                            ${dapp.icon ? `<img src="${dapp.icon}" alt="${dapp.name}" onerror="this.style.display='none'">` : ''}
                            ${!dapp.icon ? '📱' : ''}
            </div>
                        <div class="app-detail-info">
                            <h2>${this.escapeHtml(dapp.name)}</h2>
                            <p class="app-developer-link" onclick="window.app.showVendorProfile('${dapp.developer_address}')">
                                by ${this.shortenAddress(dapp.developer_address)}
                            </p>
                            <div class="app-stats">
                                <span>⬇️ ${dapp.downloads || 0} downloads</span>
                                <span>💰 ${dapp.tips || 0} MINIMA earned</span>
                    </div>
                    </div>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                    </div>
                <div class="modal-body">
                    <div class="app-description">
                        <h3>Description</h3>
                        <p>${this.escapeHtml(dapp.description)}</p>
                </div>
                    <div class="app-details">
                        <div class="detail-item">
                            <span class="detail-label">Version:</span>
                            <span class="detail-value">${dapp.version}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Category:</span>
                            <span class="detail-value">${dapp.category}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Size:</span>
                            <span class="detail-value">~${this.estimateSize(dapp)}MB</span>
                        </div>
                    </div>
                    <div class="app-actions">
                        <button class="btn-primary download-btn" onclick="window.app.downloadDapp('${dapp.uid}'); this.closest('.modal-overlay').remove();">
                            ⬇️ Download
                        </button>
                        <button class="btn-outline tip-btn" onclick="window.app.showTipModal('${dapp.developer_address}')">
                            💰 Tip Developer
                    </button>
                </div>
            </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    async showVendorProfile(developerAddress) {
        // Close any open modals first
        document.querySelectorAll('.modal-overlay').forEach(modal => modal.remove());

        const vendorDapps = this.dapps.filter(d => d.developer_address === developerAddress);
        const totalDownloads = vendorDapps.reduce((sum, d) => sum + (d.downloads || 0), 0);
        const totalTips = vendorDapps.reduce((sum, d) => sum + (d.tips || 0), 0);
        const vendorProfile = await this.loadUserProfile(developerAddress);

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal vendor-modal">
                <div class="modal-header">
                    <div class="vendor-header">
                        <div class="vendor-avatar">🎮</div>
                        <div class="vendor-info">
                            <h2>${vendorProfile.username || this.shortenAddress(developerAddress)}</h2>
                            <p class="vendor-address">${this.shortenAddress(developerAddress)}</p>
                            <div class="vendor-stats">
                                <span>${vendorDapps.length} games</span>
                                <span>${totalDownloads} downloads</span>
                                <span>${totalTips.toFixed(2)} MINIMA earned</span>
                            </div>
                        </div>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    ${vendorProfile.bio ? `<p class="vendor-bio">${this.escapeHtml(vendorProfile.bio)}</p>` : ''}
                    <div class="vendor-links">
                        ${vendorProfile.gitUrl ? `<a href="${vendorProfile.gitUrl}" target="_blank" class="vendor-link">🐙 GitHub</a>` : ''}
                        ${vendorProfile.twitterUrl ? `<a href="${vendorProfile.twitterUrl}" target="_blank" class="vendor-link">🐦 X (Twitter)</a>` : ''}
                    </div>
                    <div class="vendor-actions">
                        <button class="neon-btn" onclick="window.app.messageVendor('${developerAddress}')">
                            💬 Message
                        </button>
                        <button class="neon-btn" onclick="window.app.showTipModal('${developerAddress}')">
                            🎁 Tip Developer
                    </button>
                    </div>
                    <div class="vendor-apps">
                        <h3>🎮 Their Games</h3>
                        <div class="vendor-apps-grid">
                            ${vendorDapps.map(dapp => `
                                <div class="mini-app-card" onclick="window.app.showAppDetails('${dapp.uid}')">
                                    <div class="mini-app-icon">
                                        ${dapp.icon ? `<img src="${dapp.icon}" alt="${dapp.name}" onerror="this.style.display='none'">` : ''}
                                        ${!dapp.icon ? '🎮' : ''}
                                    </div>
                                    <div class="mini-app-info">
                                        <div class="mini-app-name">${this.escapeHtml(dapp.name)}</div>
                                        <div class="mini-app-stats">${dapp.downloads || 0} ↓ • ${dapp.tips || 0} 💰</div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                </div>
            `;

        document.body.appendChild(modal);
    }

    async messageVendor(developerAddress) {
        try {
            // Get user's Maxima address
            const maximaAddress = await window.maximaAPI.getMaximaAddress();
            if (!maximaAddress) {
                this.showToast('Unable to get your Maxima address', 'error');
                return;
            }

            // Create Maxima contact for the developer
            await window.maximaAPI.addContact(developerAddress);

            // Open Maxima chat (this would typically open the Maxima app)
            this.showToast(`Opening chat with ${this.shortenAddress(developerAddress)}`, 'success');

            // For now, just show a modal with the address
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal chat-modal">
                    <div class="modal-header">
                        <h3>💬 Maxima Chat</h3>
                        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
                    <div class="modal-body">
                        <p><strong>To:</strong> ${this.shortenAddress(developerAddress)}</p>
                        <p><strong>Your Maxima:</strong> ${this.shortenAddress(maximaAddress)}</p>
                        <p style="color: var(--text-secondary); font-size: 0.9rem; margin-top: var(--spacing-lg);">
                            Chat opened in Maxima! You can now send direct messages to this developer.
                        </p>
                        <button class="neon-btn" onclick="this.closest('.modal-overlay').remove()">
                            ✨ Got it!
                        </button>
                </div>
            </div>
        `;
            document.body.appendChild(modal);

        } catch (error) {
            console.error('MiniMart: Message vendor failed:', error);
            this.showToast('Unable to open chat', 'error');
        }
    }

    async loadUserProfile(address) {
        try {
            // Load from MDS SQL (local cache)
            const profile = await window.minimaAPI.loadProfile(address);
            return profile || {
                username: null,
                bio: 'MiniMart Developer',
                gitUrl: null,
                twitterUrl: null
            };
        } catch (error) {
            console.error('MiniMart: Failed to load profile:', error);
            return {
                username: null,
                bio: 'MiniMart Developer',
                gitUrl: null,
                twitterUrl: null
            };
        }
    }

    async checkUsernameUnique(username, currentAddress) {
        try {
            // Query blockchain for existing profiles with this username
            const result = await window.minimaAPI.cmd('coins relevant:false');
            const coins = result.response?.coins || [];

            // Look for profile coins with this username
            for (const coin of coins) {
                if (coin.state?.some(s => s.port === 'minidev_profile')) {
                    const profileState = coin.state.find(s => s.port === 'minidev_profile');
                    try {
                        const profile = JSON.parse(profileState.data);
                        if (profile.username === username && profile.address !== currentAddress) {
                            return false; // Username taken
                        }
                    } catch (e) {
                        // Skip invalid profile data
                    }
                }
            }
            return true; // Username available
        } catch (error) {
            console.error('MiniMart: Username check failed:', error);
            return true; // Default to available on error
        }
    }

    showPublishForm() {
        const container = document.getElementById('publish-form');
        if (!container) return;

        container.innerHTML = `
            <div class="publish-form">
                        <div class="form-group">
                    <label for="dapp-name">Dapp Name *</label>
                    <input type="text" id="dapp-name" placeholder="My Amazing Dapp" required>
                        </div>

                        <div class="form-group">
                    <label for="dapp-description">Description *</label>
                    <textarea id="dapp-description" placeholder="What does your dapp do?" required></textarea>
                        </div>

                <div class="form-row">
                        <div class="form-group">
                        <label for="dapp-version">Version *</label>
                        <input type="text" id="dapp-version" placeholder="1.0.0" value="1.0.0" required>
                        </div>
                        <div class="form-group">
                        <label for="dapp-category">Category</label>
                        <select id="dapp-category">
                            <option value="Utilities">Utilities</option>
                            <option value="Games">Games</option>
                            <option value="Finance">Finance</option>
                            <option value="Social">Social</option>
                            <option value="Dev Tools">Dev Tools</option>
                            </select>
                    </div>
                        </div>

                        <div class="form-group">
                    <label for="dapp-icon">Icon URL</label>
                    <input type="url" id="dapp-icon" placeholder="https://example.com/icon.png">
                </div>

                        <div class="form-group">
                    <label for="dapp-zip">MiniDapp ZIP File *</label>
                    <input type="file" id="dapp-zip" accept=".zip,.mds.zip" required>
                    <small>Upload your packaged .mds.zip file</small>
                </div>

                <div class="publish-cost">
                    <div class="cost-info">
                        <span class="cost-label">Registration Fee:</span>
                        <span class="cost-amount">0.01 MINIMA</span>
            </div>
                    <p class="cost-note">One-time fee for permanent blockchain registration</p>
                </div>

                <button class="btn-primary publish-btn" onclick="window.app.publishDapp()">
                    🚀 Publish Dapp
                            </button>
            </div>
        `;
    }

    async publishDapp() {
        try {
            const name = document.getElementById('dapp-name').value.trim();
            const description = document.getElementById('dapp-description').value.trim();
            const version = document.getElementById('dapp-version').value.trim();
            const category = document.getElementById('dapp-category').value;
            const icon = document.getElementById('dapp-icon').value.trim();
            const zipFile = document.getElementById('dapp-zip').files[0];

            if (!name || !description || !version || !zipFile) {
                this.showToast('Please fill in all required fields.', 'error');
                return;
            }

            this.showToast('Publishing your dapp...', 'info');

            // Upload ZIP to IPFS
            console.log('MiniMart: Uploading ZIP to IPFS...');
            const ipfsHash = await window.ipfsAPI.uploadFile(zipFile);
            console.log('MiniMart: ZIP uploaded to IPFS:', ipfsHash);

            // Create dapp data
            const dappData = {
                uid: this.generateUid(),
                name,
                description,
                version,
                category,
                icon: icon || null,
                ipfs_hash: ipfsHash,
                developer_address: window.minimaAPI.getCurrentAddress(),
                timestamp: Date.now()
            };

            // Register on blockchain
            console.log('MiniMart: Registering on blockchain...');
            const txId = await window.blockchainAPI.registerDapp(dappData);
            console.log('MiniMart: Registered with TX:', txId);

            // Broadcast via Maxima
            console.log('MiniMart: Broadcasting via Maxima...');
            await window.maximaAPI.broadcastNewDapp(dappData);

            this.showToast('Dapp published successfully!', 'success');
            this.switchView('marketplace');

        } catch (error) {
            console.error('MiniMart: Publish failed:', error);
            this.showToast('Failed to publish dapp. Please try again.', 'error');
        }
    }

    async showProfile() {
        console.log('MiniMart: showProfile called');
        const container = document.getElementById('profile-content');
        if (!container) {
            console.error('MiniMart: profile-content container not found');
            this.showToast('Profile container not found', 'error');
            return;
        }


        try {
            // Get user address from Minima node
            const userAddress = await this.getUserMinimaAddress();
            console.log('MiniMart: User Minima address:', userAddress);

            if (!userAddress) {
        container.innerHTML = `
                    <div class="profile-container">
                        <div class="error-state">
                            <div class="error-icon">❌</div>
                            <h3>Cannot Load Profile</h3>
                            <p>Unable to connect to your Minima node.</p>
                            <button class="neon-btn" onclick="window.app.showProfile()">Retry</button>
                        </div>
            </div>
        `;
                return;
            }

            const userDapps = this.dapps.filter(d => d.developer_address === userAddress);
            console.log('MiniMart: User has', userDapps.length, 'dapps');

            // Load profile from blockchain/local storage
            const profile = await this.loadUserProfile(userAddress);
            console.log('MiniMart: Loaded profile:', profile);

            // Render profile
            container.innerHTML = this.renderProfile(userAddress, userDapps, profile);

        } catch (error) {
            console.error('MiniMart: Profile loading failed:', error);
            container.innerHTML = `
                <div class="profile-container">
                    <div class="error-state">
                        <div class="error-icon">❌</div>
                        <h3>Profile Error</h3>
                        <p>${error.message || 'Failed to load profile'}</p>
                        <button class="neon-btn" onclick="window.app.showProfile()">Retry</button>
                    </div>
                </div>
            `;
        }
    }

    async getUserMinimaAddress() {
        try {
            // Try to get balance first to see if we can extract address
            const balanceResult = await window.minimaAPI.cmd('balance');
            if (balanceResult.response && balanceResult.response.length > 0) {
                // Use the first balance entry's address
                const firstBalance = balanceResult.response[0];
                if (firstBalance.address) {
                    return firstBalance.address;
                }
            }

            // Fallback: try getaddress command
            const addressResult = await window.minimaAPI.cmd('getaddress');
            if (addressResult.response) {
                // getaddress returns a script, but we need an actual address
                // For now, let's create a hash of the script to use as identifier
                const script = addressResult.response.script || addressResult.response;
                // Simple hash function for identifier
                let hash = 0;
                for (let i = 0; i < script.length; i++) {
                    const char = script.charCodeAt(i);
                    hash = ((hash << 5) - hash) + char;
                    hash = hash & hash; // Convert to 32-bit integer
                }
                return Math.abs(hash).toString(16).padStart(8, '0');
            }

            // Last fallback
            return 'anonymous_' + Date.now();
        } catch (error) {
            console.error('MiniMart: Failed to get user address:', error);
            return 'anonymous_' + Date.now();
        }
    }

    async addTreasuryStatus(container) {
        // Estimate treasury balance (this would be more accurate with actual treasury tracking)
        const totalUsers = this.dapps.length * 2; // Rough estimate: 2 profiles per dapp
        const estimatedTreasury = totalUsers * 0.01; // 0.01 MINIMA per user

        const treasuryHTML = `
            <div class="treasury-status">
                <div class="treasury-header">
                    <span class="treasury-bank-icon">🏦</span>
                    <span class="treasury-title">MiniMart Treasury</span>
                </div>
                <div class="treasury-stats">
                    <div class="treasury-amount">
                        <span class="amount">${estimatedTreasury.toFixed(2)}</span>
                        <span class="currency">MINIMA</span>
                    </div>
                    <div class="treasury-breakdown">
                        <div class="breakdown-item">
                            <span class="breakdown-label">Developer Rewards</span>
                            <span class="breakdown-value">60%</span>
                        </div>
                        <div class="breakdown-item">
                            <span class="breakdown-label">Platform Growth</span>
                            <span class="breakdown-value">30%</span>
                        </div>
                        <div class="breakdown-item">
                            <span class="breakdown-label">Community Fund</span>
                            <span class="breakdown-value">10%</span>
                        </div>
                    </div>
                </div>
                <div class="treasury-message">
                    💰 Your contributions fund the future of MiniMart! 🎮
                </div>
            </div>
        `;

        // Insert treasury status at the top
        container.insertAdjacentHTML('afterbegin', treasuryHTML);
    }

    renderProfile(userAddress, userDapps, profile) {
        return `
            <div class="profile-container">
                <div class="profile-header-section">
                    <div class="profile-info">
                        <h1 class="profile-username">${this.escapeHtml(profile.username || 'Anonymous')}</h1>
                        <p class="profile-address">${this.shortenAddress(userAddress)}</p>
                        <button class="neon-btn edit-profile-btn" onclick="window.app.editProfile()">
                            ⚡ Edit Profile (0.01 MINIMA)
                        </button>
                    </div>
                </div>

                <div class="profile-links">
                    ${profile.gitUrl ? `<a href="${profile.gitUrl}" target="_blank" class="profile-link">🐙 GitHub</a>` : ''}
                    ${profile.twitterUrl ? `<a href="${profile.twitterUrl}" target="_blank" class="profile-link">🐦 X (Twitter)</a>` : ''}
                </div>

                <div class="profile-stats-grid">
                    <div class="stat-card">
                        <div class="stat-number">${userDapps.length}</div>
                        <div class="stat-label">Apps Published</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">${userDapps.reduce((sum, d) => sum + (d.downloads || 0), 0)}</div>
                        <div class="stat-label">Total Downloads</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">${userDapps.reduce((sum, d) => sum + (d.tips || 0), 0).toFixed(2)}</div>
                        <div class="stat-label">MINIMA Earned</div>
                    </div>
                </div>

                ${userDapps.length === 0 ? `
                    <div class="empty-profile">
                        <div class="empty-icon">🎮</div>
                        <h3>No Games Yet!</h3>
                        <p>Publish your first game to get started!</p>
                        <button class="neon-btn" onclick="window.app.switchView('publish')">
                            🎯 Publish Your First Game
                        </button>
                    </div>
                ` : `
                    <div class="profile-apps">
                        <h3>🎮 Your Games</h3>
                        <div class="profile-apps-grid">
                            ${userDapps.map(dapp => `
                                <div class="profile-app-card" onclick="window.app.showAppDetails('${dapp.uid}')">
                                    <div class="profile-app-icon">
                                        ${dapp.icon ? `<img src="${dapp.icon}" alt="${dapp.name}" onerror="this.style.display='none'">` : ''}
                                        ${!dapp.icon ? '🎮' : ''}
                                    </div>
                                    <div class="profile-app-info">
                                        <h4>${this.escapeHtml(dapp.name)}</h4>
                                        <div class="profile-app-stats">
                                            <span>⬇️ ${dapp.downloads || 0}</span>
                                            <span>💰 ${dapp.tips || 0}</span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `}
            </div>
        `;
    }

    async editProfile() {
        const userAddress = await this.getUserMinimaAddress();
        if (!userAddress) {
            this.showToast('Cannot get user address', 'error');
            return;
        }

        const currentProfile = await this.loadUserProfile(userAddress);

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal profile-edit-modal">
                <div class="modal-header">
                    <h3>⚡ Edit Your Profile</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                        <div class="form-group">
                        <label for="profile-username">🎮 Username *</label>
                        <input type="text" id="profile-username" placeholder="Your unique username" maxlength="20" value="${currentProfile.username || ''}">
                        <small>Unique username (costs 0.01 MINIMA)</small>
                        <div id="username-check" class="username-check"></div>
                        </div>
                        <div class="form-group">
                        <label for="profile-bio">📝 Bio</label>
                        <textarea id="profile-bio" placeholder="Tell gamers about yourself!" maxlength="160">${currentProfile.bio || ''}</textarea>
                        </div>
                        <div class="form-group">
                        <label for="profile-github">🐙 GitHub</label>
                        <input type="url" id="profile-github" placeholder="https://github.com/username" value="${currentProfile.gitUrl || ''}">
                        </div>
                        <div class="form-group">
                        <label for="profile-twitter">🐦 X (Twitter)</label>
                        <input type="url" id="profile-twitter" placeholder="https://x.com/username" value="${currentProfile.twitterUrl || ''}">
                        </div>
                    <div class="treasury-info">
                        <div class="treasury-notice">
                            <strong>⚡ Cost: 0.01 MINIMA</strong> to create permanent identity
                        </div>
                        <div class="treasury-benefit">
                            <span class="treasury-icon">💰</span>
                            <span class="treasury-text">Funds MiniMart Treasury for:</span>
                            <ul class="treasury-list">
                                <li>🎁 Developer rewards & bounties</li>
                                <li>🚀 Platform improvements</li>
                                <li>🏆 Community initiatives</li>
                            </ul>
                                </div>
                                </div>
                    <button class="neon-btn" onclick="window.app.saveProfile()">
                        ✨ Save Profile
                            </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Add username uniqueness checking
        const usernameInput = document.getElementById('profile-username');
        const checkDiv = document.getElementById('username-check');

        usernameInput.addEventListener('input', async (e) => {
            const username = e.target.value.trim();
            if (username.length < 3) {
                checkDiv.innerHTML = '<span style="color: var(--text-secondary);">⚡ Username must be at least 3 characters</span>';
                return;
            }

            checkDiv.innerHTML = '<span style="color: var(--text-secondary);">🔍 Checking availability...</span>';

            const isAvailable = await this.checkUsernameUnique(username, window.minimaAPI.getCurrentAddress());

            if (isAvailable) {
                checkDiv.innerHTML = '<span style="color: var(--accent-success);">✅ Username available!</span>';
            } else {
                checkDiv.innerHTML = '<span style="color: var(--accent-error);">❌ Username taken</span>';
            }
        });
    }

    async saveProfile() {
        try {
            const username = document.getElementById('profile-username').value.trim();
            const bio = document.getElementById('profile-bio').value.trim();
            const github = document.getElementById('profile-github').value.trim();
            const twitter = document.getElementById('profile-twitter').value.trim();

            // Get user's Minima address
            const userAddress = await this.getUserMinimaAddress();
            if (!userAddress) {
                this.showToast('❌ Cannot get your Minima address!', 'error');
                return;
            }

            if (!username) {
                this.showToast('🎮 Username is required!', 'error');
                return;
            }

            if (username.length < 3) {
                this.showToast('⚡ Username must be at least 3 characters!', 'error');
                return;
            }

            // Check username uniqueness
            const isAvailable = await this.checkUsernameUnique(username, userAddress);
            if (!isAvailable) {
                this.showToast('❌ Username already taken!', 'error');
                return;
            }

            // Check balance and send 0.01 MINIMA for permanent identity
            const balance = await window.minimaAPI.getBalance();
            if (parseFloat(balance.confirmed) < 0.01) {
                this.showToast('💰 Need 0.01 MINIMA to create permanent identity!', 'error');
                return;
            }

            this.showToast('⚡ Creating permanent identity...', 'info');

            // Send 0.01 MINIMA to MiniMart treasury for permanent identity creation
            // This funds the community treasury for developer rewards and platform growth
            const treasuryAddress = 'MxG086AUGQMWM6S47P6GWR2U1AV3391EPR5Q53N7DN9MGNMMN6BMH270SV8QRSC'; // MiniMart Treasury (your address)

            try {
                await window.minimaAPI.send('0.01', treasuryAddress);
            } catch (error) {
                if (error.message && error.message.includes('pending')) {
                    // This is expected! Show success and redirect to pending
                    this.showToast('🎯 Transaction created! Go to Pending tab to approve the 0.01 MINIMA payment.', 'success');

                    // Create profile data for after approval
                    const profileData = {
                        username,
                        bio: bio || '🎮 MiniMart Game Developer',
                        gitUrl: github || null,
                        twitterUrl: twitter || null,
                        address: userAddress,
                        timestamp: Date.now(),
                        identity_created: true
                    };

                    // Store temporarily for after approval
                    localStorage.setItem('pending_profile', JSON.stringify(profileData));

                    // Close modal and switch to pending view
                    document.querySelector('.modal-overlay').remove();
                    this.switchView('pending');

                    return; // Exit early - user needs to approve first
                } else if (error.message && error.message.includes('Insufficient')) {
                    this.showToast('💰 Need 0.01 MINIMA to create identity!', 'error');
                    return;
                } else {
                    throw error;
                }
            }

            // If we get here, transaction was approved immediately
            await this.completeProfileCreation(userAddress, username, bio, github, twitter);

        } catch (error) {
            console.error('MiniMart: Profile creation failed:', error);
            this.showToast('❌ Failed to create identity. Please try again.', 'error');
        }
    }

    async completeProfileCreation(userAddress, username, bio, github, twitter) {
        // Create profile data
        const profileData = {
            username,
            bio: bio || '🎮 MiniMart Game Developer',
            gitUrl: github || null,
            twitterUrl: twitter || null,
            address: userAddress,
            timestamp: Date.now(),
            identity_created: true
        };

        // Broadcast via Maxima for live updates to other users
        await window.maximaAPI.broadcastProfileUpdate(profileData);

        // Store locally for immediate access
        this.profiles[userAddress] = profileData;

        // Close modal and refresh profile
        document.querySelector('.modal-overlay').remove();
        this.showProfile();

        this.showToast('✨ Permanent identity created!', 'success');
    }

    async showTipModal(developerAddress) {
        const developerProfile = await this.loadUserProfile(developerAddress);

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal tip-modal">
                <div class="modal-header">
                    <h3>🎁 Tip ${developerProfile.username || this.shortenAddress(developerAddress)}</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <p>Show your appreciation! 💰</p>
                    <div class="tip-presets">
                        <button class="tip-preset" data-amount="0.01">0.01</button>
                        <button class="tip-preset" data-amount="0.1">0.1</button>
                        <button class="tip-preset" data-amount="1">1</button>
                        <button class="tip-preset" data-amount="5">5</button>
                        </div>
                    <div class="custom-tip">
                        <input type="number" id="custom-tip-amount" placeholder="Custom amount" step="0.01" min="0.01">
                        <span>MINIMA</span>
                        </div>
                    <button class="neon-btn" onclick="window.app.sendTip('${developerAddress}')">
                        🎁 Send Tip
                            </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Setup preset buttons
        modal.querySelectorAll('.tip-preset').forEach(btn => {
            btn.addEventListener('click', () => {
                const amount = btn.dataset.amount;
                document.getElementById('custom-tip-amount').value = amount;
                modal.querySelectorAll('.tip-preset').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
            });
        });
    }

    async sendTip(developerAddress) {
        try {
            const amount = parseFloat(document.getElementById('custom-tip-amount').value);

            if (!amount || amount <= 0) {
                this.showToast('💰 Please enter a valid tip amount!', 'error');
                return;
            }

            // Check balance
            const balance = await window.minimaAPI.getBalance();
            if (parseFloat(balance.confirmed) < amount) {
                this.showToast('💰 Insufficient balance!', 'error');
                return;
            }

            this.showToast('🎁 Sending tip...', 'info');

            // Send tip via Minima
            await window.minimaAPI.send(amount.toString(), developerAddress);

            // Send Maxima notification to developer
            await window.maximaAPI.broadcastTip(amount, developerAddress, window.minimaAPI.getCurrentAddress());

            // Update local tip count for this developer
            const dapp = this.dapps.find(d => d.developer_address === developerAddress);
            if (dapp) {
                dapp.tips = (dapp.tips || 0) + amount;
            }

            // Close modal
            document.querySelector('.modal-overlay').remove();

            this.showToast(`🎁 Tip of ${amount} MINIMA sent!`, 'success');

        } catch (error) {
            console.error('MiniMart: Tip failed:', error);
            this.showToast('❌ Failed to send tip!', 'error');
        }
    }

    showTreasuryModal() {
        // Calculate current treasury estimate
        const totalUsers = Math.max(this.dapps.length * 2, 1);
        const estimatedTreasury = totalUsers * 0.01;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal treasury-modal">
                <div class="modal-header">
                    <h3>🏦 MiniMart Treasury</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="treasury-status">
                        <div class="treasury-header">
                            <span class="treasury-bank-icon">🏦</span>
                            <span class="treasury-title">Community Treasury</span>
                        </div>
                        <div class="treasury-stats">
                            <div class="treasury-amount">
                                <span class="amount">${estimatedTreasury.toFixed(2)}</span>
                                <span class="currency">MINIMA</span>
                            </div>
                            <div class="treasury-breakdown">
                                <div class="breakdown-item">
                                    <span class="breakdown-label">Developer Rewards</span>
                                    <span class="breakdown-value">60%</span>
                                </div>
                                <div class="breakdown-item">
                                    <span class="breakdown-label">Platform Growth</span>
                                    <span class="breakdown-value">30%</span>
                                </div>
                                <div class="breakdown-item">
                                    <span class="breakdown-label">Community Fund</span>
                                    <span class="breakdown-value">10%</span>
                                </div>
                            </div>
                        </div>
                        <div class="treasury-message">
                            💰 Your contributions fund the future of MiniMart! 🎮
                        </div>
                    </div>

                    <div class="treasury-info">
                        <h4>How Treasury Works</h4>
                        <ul>
                            <li>🎯 <strong>0.01 MINIMA</strong> per profile creation</li>
                            <li>🚀 <strong>0.01 MINIMA</strong> per dapp registration</li>
                            <li>🎁 <strong>60%</strong> goes to developer rewards & bounties</li>
                            <li>🏗️ <strong>30%</strong> funds platform improvements</li>
                            <li>🤝 <strong>10%</strong> supports community initiatives</li>
                        </ul>

                        <div class="treasury-address">
                            <strong>Treasury Address:</strong><br>
                            <code>MxG086AUGQMWM6S47P6GWR2U1AV3391EPR5Q53N7DN9MGNMMN6BMH270SV8QRSC</code>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    async showPending() {
        const container = document.getElementById('pending-content');
        if (!container) {
            console.error('MiniMart: pending-content container not found');
            return;
        }

        try {
            // Check for pending transactions
            const pendingResult = await window.minimaAPI.cmd('pending');

            container.innerHTML = `
                <div class="pending-header">
                    <h2>⏳ Pending Transactions</h2>
                    <p>Approve or deny transactions requiring your confirmation</p>
                </div>

                <div class="pending-refresh">
                    <button class="neon-btn" onclick="window.app.showPending()">🔄 Refresh</button>
                </div>
            `;

            if (pendingResult.response && pendingResult.response.length > 0) {
                const pendingList = pendingResult.response.map(tx => `
                    <div class="pending-item">
                        <div class="pending-info">
                            <div class="pending-amount">💰 ${tx.amount || 'Unknown'} MINIMA</div>
                            <div class="pending-to">To: ${tx.to || tx.address || 'Unknown'}</div>
                            <div class="pending-id">ID: ${tx.id || tx.uid || 'Unknown'}</div>
                        </div>
                        <div class="pending-actions">
                            <button class="neon-btn approve-btn" onclick="window.app.approveTransaction('${tx.id || tx.uid}')">
                                ✅ Approve
                            </button>
                            <button class="btn-outline deny-btn" onclick="window.app.denyTransaction('${tx.id || tx.uid}')">
                                ❌ Deny
                            </button>
                        </div>
                    </div>
                `).join('');

                container.innerHTML += `
                    <div class="pending-list">
                        ${pendingList}
                    </div>
                `;
            } else {
                container.innerHTML += `
                    <div class="no-pending">
                        <div class="no-pending-icon">✅</div>
                        <h3>No Pending Transactions</h3>
                        <p>All transactions have been processed!</p>
                    </div>
                `;
            }

            // Check for pending profile creation
            const pendingProfile = localStorage.getItem('pending_profile');
            if (pendingProfile) {
                container.innerHTML += `
                    <div class="pending-profile-notice">
                        <div class="notice-icon">👤</div>
                        <div class="notice-text">
                            <strong>Profile Creation Pending</strong><br>
                            Approve the 0.01 MINIMA transaction above to complete your permanent identity!
                        </div>
                    </div>
                `;
            }

        } catch (error) {
            console.error('MiniMart: Failed to load pending transactions:', error);
            container.innerHTML = `
                <div class="error-state">
                    <div class="error-icon">❌</div>
                    <h3>Failed to Load Pending</h3>
                    <p>${error.message || 'Unable to check pending transactions'}</p>
                    <button class="neon-btn" onclick="window.app.showPending()">Retry</button>
                </div>
            `;
        }
    }

    async approveTransaction(txId) {
        try {
            this.showToast('🔄 Approving transaction...', 'info');

            // Approve the transaction
            await window.minimaAPI.cmd(`mds action:accept uid:${txId}`);

            // Check if this was a profile creation
            const pendingProfile = localStorage.getItem('pending_profile');
            if (pendingProfile) {
                const profileData = JSON.parse(pendingProfile);
                localStorage.removeItem('pending_profile');

                // Complete profile creation
                await this.completeProfileCreation(
                    profileData.address,
                    profileData.username,
                    profileData.bio,
                    profileData.gitUrl,
                    profileData.twitterUrl
                );

                // Switch back to profile view
                this.switchView('profile');
            } else {
                this.showToast('✅ Transaction approved!', 'success');
                this.showPending(); // Refresh the list
            }

        } catch (error) {
            console.error('MiniMart: Failed to approve transaction:', error);
            this.showToast('❌ Failed to approve transaction', 'error');
        }
    }

    async denyTransaction(txId) {
        try {
            this.showToast('🔄 Denying transaction...', 'info');

            // Deny the transaction
            await window.minimaAPI.cmd(`mds action:deny uid:${txId}`);

            // Clear any pending profile data
            localStorage.removeItem('pending_profile');

            this.showToast('❌ Transaction denied', 'warning');
            this.showPending(); // Refresh the list

        } catch (error) {
            console.error('MiniMart: Failed to deny transaction:', error);
            this.showToast('❌ Failed to deny transaction', 'error');
        }
    }

    editDapp(dappUid) {
        this.showToast('Dapp management coming soon!', 'info');
    }

    shortenAddress(address) {
        if (!address) return 'Unknown';
        return address.substring(0, 6) + '...' + address.substring(address.length - 4);
    }

    estimateSize(dapp) {
        // Rough estimate based on IPFS hash (each char ~ 1KB)
        return Math.max(1, Math.floor((dapp.ipfs_hash || '').length / 10));
    }

    generateUid() {
        return '0x' + Math.random().toString(16).substr(2, 64).toUpperCase();
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showToast(message, type = 'info') {
        // Simple toast implementation
        console.log(`MiniMart ${type.toUpperCase()}:`, message);

        // For now, just use alert for simplicity
        if (type === 'error') {
            alert(`❌ Error: ${message}`);
        } else if (type === 'success') {
            alert(`✅ ${message}`);
        } else {
            alert(`ℹ️ ${message}`);
        }
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    hideLoading() {
        const loading = document.getElementById('loading');
        const app = document.getElementById('app');

        if (loading) loading.classList.add('hidden');
        if (app) app.classList.remove('hidden');
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('MiniMart: DOM ready, creating app...');
    window.app = new MiniMartApp();
    window.app.init();
});
