// TestDapp - Simple MiniDapp for MiniMart publishing demo

class TestDapp {
    constructor() {
        this.isReady = false;
        this.init();
    }

    async init() {
        try {
            // Wait for MDS to be ready
            if (typeof MDS === 'undefined') {
                console.log('Waiting for MDS...');
                setTimeout(() => this.init(), 1000);
                return;
            }

            console.log('TestDapp: Initializing...');

            // Get system information
            await this.loadSystemInfo();

            this.isReady = true;
            console.log('TestDapp: Ready!');

        } catch (error) {
            console.error('TestDapp init failed:', error);
        }
    }

    async loadSystemInfo() {
        try {
            // Get block height
            const statusResult = await this.cmd('status');
            if (statusResult.response) {
                const blockHeight = statusResult.response.chain.block || 'Unknown';
                document.getElementById('block-height').textContent = blockHeight;
            }

            // Get balance
            const balanceResult = await this.cmd('balance');
            if (balanceResult.response && balanceResult.response.balance) {
                const minimaBalance = balanceResult.response.balance.find(b => b.token === 'Minima') || { confirmed: '0' };
                document.getElementById('balance').textContent = minimaBalance.confirmed + ' MINIMA';
            }

            // Get address
            const addressResult = await this.cmd('getaddress');
            if (addressResult.response && addressResult.response.address) {
                const shortAddr = addressResult.response.address.substring(0, 8) + '...' +
                                addressResult.response.address.substring(addressResult.response.address.length - 8);
                document.getElementById('user-address').textContent = shortAddr;
            }

        } catch (error) {
            console.error('Failed to load system info:', error);
        }
    }

    async cmd(command) {
        return new Promise((resolve, reject) => {
            MDS.cmd(command, (result) => {
                if (result.status) {
                    resolve(result);
                } else {
                    reject(new Error(result.error || 'Command failed'));
                }
            });
        });
    }
}

// Global functions
function showInfo() {
    const infoDiv = document.getElementById('system-info');
    infoDiv.style.display = infoDiv.style.display === 'none' ? 'block' : 'none';
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.testDapp = new TestDapp();
});
